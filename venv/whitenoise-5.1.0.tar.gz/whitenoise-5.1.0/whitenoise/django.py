raise ImportError(
    "\n\n"
    "Your WhiteNoise configuration is incompatible with WhiteNoise v4.0\n"
    "This can be fixed by following the upgrade instructions at:\n"
    "http://whitenoise.evans.io/en/stable/changelog.html#v4-0\n"
    "\n"
)
